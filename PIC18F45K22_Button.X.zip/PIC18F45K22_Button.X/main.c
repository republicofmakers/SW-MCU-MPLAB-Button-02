/*
 * File:   main.c
 * Author: Ceyhun Pempeci
 *
 * Created on January 10, 2025, 9:25 AM
 */


#include "CONFIG.h"

#define _XTAL_FREQ 64000000


void main(void) {
    
    
    TRISD0 = 0; // LED: D0 is in output mode
    
    TRISD2 = 1; //Button: D2 is in input mode / Pulled Down
    
    ANSD2 = 0;
    
    while(1)
    {
        
        if(PORTDbits.RD2)
        {
        
            LATD0 = 1;
            
        }
        
        else
        {
              
            LATD0 = 0;
            
        }
    }
    
    
    return;
}
